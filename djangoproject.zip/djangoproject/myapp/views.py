from django.shortcuts import render
from django.http import HttpResponse
from django.views.generic import ListView
from django.views.generic.base import TemplateView
from .models import Student

def homepageview(request):
    return render(request,'home.html')


def aboutpageview(request):
    return render(request,'about.html')

def contactpageview(request):
    return render(request,'contact.html')

def myform(request):
    return render(request,'myform.html')

def process(request): 
    print("Welcome")
    print(request.method)
    print(request.POST)
    a = int(request.POST['txt1'])
    b = int(request.POST['txt2'])
    c = a + b
    print(c)
    return render(request,'ans.html',{'mya':a,'myb':b,'mysum' :c})

def signup(request):
    return render(request,'signup.html')

def details(request):
    print(request.method)
    print(request.POST)
    First_Name = str(request.POST.get('txt'))
    Last_Name = str(request.POST.get('txt2'))
    Password = str(request.POST.get('pass'))
    Gender = str(request.POST.get('gen'))
    Email = str(request.POST.get('mail'))
    Number = str(request.POST.get('no.'))
    Git = str(request.POST.get('git'))
    Institute = str(request.POST.get('insti'))
    Course = str(request.POST.get('course'))

    return render(request,'details.html',{'fname':First_Name,'lname':Last_Name,'Pass': Password,'gen':Gender,'mail': Email,'no.':Number,'git': Git,'insti':Institute,'course':Course})


class studentlist(ListView):
    model = Student
    template_name = 'slist.html'